/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Empresa;

/**
 *
 * @author LabSispc20
 */
public class Coche {
    private String brand;
    private String model;
    private String registration;

    public Coche(String brand, String model, String registration) {
        this.brand = brand;
        this.model = model;
        this.registration = registration;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getRegistration() {
        return registration;
    }

    public void setRegistration(String registration) {
        this.registration = registration;
    }

    @Override
    public String toString() {
        return "Coche{" + "brand=" + brand + ", model=" + model + ", registration=" + registration + '}';
    }
    
    
}
