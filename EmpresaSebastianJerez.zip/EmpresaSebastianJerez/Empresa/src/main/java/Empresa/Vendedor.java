/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Empresa;
import java.util.ArrayList;

/**
 *
 * @author LabSispc20
 */
public class Vendedor extends Empleado{
    private Coche vehicle;
    private String movilPhone;
    private String saleArea;
    private Cliente client;
    private int comisions;

    public Vendedor(String movilPhone, String saleArea, int comisions, String name, String surname, String dni, String address, double salary, String phoneNumber, int yearsOfService) {
        super(name, surname, dni, address, salary, phoneNumber, yearsOfService);
        this.movilPhone = movilPhone;
        this.saleArea = saleArea;
        this.comisions = comisions;
        for(int i=0;i<this.getYearsOfService();i++){
            this.increastSalary();
        }
    }

    public String getMovilPhone() {
        return movilPhone;
    }

    public void setMovilPhone(String movilPhone) {
        this.movilPhone = movilPhone;
    }

    public String getSaleArea() {
        return saleArea;
    }

    public void setSaleArea(String saleArea) {
        this.saleArea = saleArea;
    }

    public int getComisions() {
        return comisions;
    }

    public void setComisions(int comisions) {
        this.comisions = comisions;
    }

    public void setVehicle(Coche vehicle) {
        this.vehicle = vehicle;
    }
    
    public Coche getVehicle(){
        return vehicle;
    }

    public Cliente getClient() {
        return client;
    }

    public void setClient(Cliente client) {
        this.client = client;
    }
    
    
    
    @Override
    public void increastSalary(){
        double salary = this.getSalary();
        salary = salary+(salary*0.1);
        this.setSalary(salary);
    }

    @Override
    public String toString() {
        return "Vendedor{" + "name=" + this.getName() + ", surname=" + this.getSurname() + ", dni=" + this.getDni() + ", address=" + this.getAddress() + ", salary=" + this.getSalary() + ", yearsOfService=" + this.getYearsOfService() + ", phoneNumber=" + this.getPhoneNumber() + "movilPhone=" + movilPhone + ", saleArea=" + saleArea + ", comisions=" + comisions + '}';
    }
}
