/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package Empresa;

import java.util.Scanner;

/**
 *
 * @author LabSispc20
 */
public class Main {
    
    private static Coche car;
    private static Secretario secretary;
    private static Vendedor salesman;
    private static JefeZona boss;
    private static Cliente clientSalesman;
    private static Cliente clientBoss;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        input.useDelimiter("\n");
        
        int menu = 0;
        int subMenu = 0;
        
        do{
            menu = Menu(input);
            
            switch(menu){
                case 1:{
                    subMenu = subMenuSecretario(input);
                    switch(subMenu){
                        case 1:{
                            secretario(input);
                            break;
                        }
                        case 2:{
                            asignarSupervisor(input,secretary);
                            break;
                        }
                        case 3:{
                            System.out.println(secretary.toString());
                            break;
                        }
                    }
                    break;
                }
                case 2:{
                    subMenu = subMenuVendedor(input);
                    switch(subMenu){
                        case 1:{
                            vendedor(input);
                            break;
                        }
                        case 2:{
                            asignarSupervisor(input,salesman);
                            break;
                        }
                        case 3:{
                            agregarCliente(input,salesman);
                            break;
                        }
                        case 4:{
                            eliminarCliente(input,salesman);
                            break;
                        }
                        case 5:{
                            salesman.setVehicle(car);
                            System.out.println("Vehiculo"+car.getBrand()+" asignado existosamente");
                            break;
                        }
                        case 6:{
                            System.out.println(salesman.toString());
                            break;
                        }
                    }
                    break;
                }
                case 3:{
                    subMenu = subMenuJefe(input);
                    switch(subMenu){
                        case 1:{
                            jefe(input);
                            break;
                        }
                        case 2:{
                            asignarSupervisor(input,boss);
                            break;
                        }
                        case 3:{
                            boss.setSecretary(secretary);
                            break;
                        }
                        case 4:{
                            agregarCliente(input,boss);
                            break;
                        }
                        case 5:{
                            eliminarCliente(input,boss);
                            break;
                        }
                        case 6:{
                            boss.setVehicle(car);
                            System.out.println("Vehiculo"+car.getBrand()+" asignado existosamente");
                            break;
                        }
                        case 7:{
                            System.out.println(boss.toString());
                            break;
                        }
                    }
                    break;
                }
                case 4:{
                    crearCoche(input);
                    break;
                }
                case 5:{
                    System.exit(0);
                    break;
                }
            }
        }while(menu!=9);
    }
    
    public static int Menu(Scanner input){
        System.out.println("Escoja una opcion:");
        System.out.println("1. Secretario ");
        System.out.println("2. Vendedor");
        System.out.println("3. Jefe de Zona");
        System.out.println("4. Crear Carros");
        System.out.println("5. Salir");
        int value=1;
        do{
            value = input.nextInt();
            if(value<1||value>5){
                System.out.println("Opcion no valida, intente de nuevo");
            }
        }while(value<1||value>5);
        return value;
    }
    
    public static int subMenuSecretario(Scanner input){
        System.out.println("Selecciona que accion hacer:");
        System.out.println("1. Crear");
        System.out.println("2. Asignar Supervisor");
        System.out.println("3. Mostrar info");
        int value=1;
        do{
            value = input.nextInt();
            if(value<1||value>3){
                System.out.println("Opcion no valida, intente de nuevo");
            }
        }while(value<1||value>3);
        return value;
    }
    
    public static int subMenuVendedor(Scanner input){
        System.out.println("Selecciona que accion hacer:");
        System.out.println("1. Crear");
        System.out.println("2. Asignar Supervisor");
        System.out.println("3. Agregar Cliente");
        System.out.println("4. Eliminar Cliente");
        System.out.println("5. Asignar Coche");
        System.out.println("6. Mostrar Info");
        int value=1;
        do{
            value = input.nextInt();
            if(value<1||value>6){
                System.out.println("Opcion no valida, intente de nuevo");
            }
        }while(value<1||value>6);
        return value;
    }
    
    public static int subMenuJefe(Scanner input){
        System.out.println("Selecciona que accion hacer:");
        System.out.println("1. Crear");
        System.out.println("2. Asignar Supervisor");
        System.out.println("3. Asignar Secretario");
        System.out.println("4. Agregar Cliente");
        System.out.println("5. Eliminar Cliente");
        System.out.println("6. Asignar Coche");
        System.out.println("7. Mostrar info");
        int value=1;
        do{
            value = input.nextInt();
            if(value<1||value>7){
                System.out.println("Opcion no valida, intente de nuevo");
            }
        }while(value<1||value>7);
        return value;
    }
    
    public static void crearCoche(Scanner input){
        System.out.println("Marca: ");
        String brand = input.next();
        System.out.println("Modelo:");
        String model = input.next();
        System.out.println("Placa:");
        String registration = input.next();
        
        car = new Coche(brand,model,registration);
    }
    
    public static void secretario(Scanner input){
        System.out.println("nombre");
        String name = input.next();
        System.out.println("apellido");
        String surname = input.next();
        System.out.println("DNI");
        String dni = input.next();
        System.out.println("Direccion");
        String address = input.next();
        System.out.println("Salario");
        double salary = input.nextDouble();
        System.out.println("Telefono");
        String phone = input.next();
        System.out.println("Años de antiguedad");
        int years = input.nextInt();
        System.out.println("Despacho");
        String office = input.next();
        System.out.println("numero fax");
        String fax = input.next();
        
        secretary = new Secretario(office,fax,name,surname,dni,address,salary,phone,years);        
    }
    
    public static void vendedor(Scanner input){
        System.out.println("nombre");
        String name = input.next();
        System.out.println("apellido");
        String surname = input.next();
        System.out.println("DNI");
        String dni = input.next();
        System.out.println("Direccion");
        String address = input.next();
        System.out.println("Salario");
        double salary = input.nextDouble();
        System.out.println("Telefono");
        String phone = input.next();
        System.out.println("Años de antiguedad");
        int years = input.nextInt();
        System.out.println("Celular");
        String movil = input.next();
        System.out.println("Area de ventas");
        String salesArea = input.next();
        System.out.println("Porcentaje de comisiones");
        int comisions = input.nextInt();
        
        salesman = new Vendedor(movil,salesArea,comisions,name,surname,dni,address,salary,phone,years);
    }
    
    public static void jefe(Scanner input){
        System.out.println("nombre");
        String name = input.next();
        System.out.println("apellido");
        String surname = input.next();
        System.out.println("DNI");
        String dni = input.next();
        System.out.println("Direccion");
        String address = input.next();
        System.out.println("Salario");
        double salary = input.nextDouble();
        System.out.println("Telefono");
        String phone = input.next();
        System.out.println("Años de antiguedad");
        int years = input.nextInt();
        System.out.println("Despacho");
        String office = input.next();
        
        boss = new JefeZona(office,name,surname,dni,address,salary,phone,years);
    }
    
    public static void asignarSupervisor(Scanner input, Empleado employee){
        System.out.println("Nombre del supervisor");
        String name = input.next();
        if(name.equals(secretary.getName())){
            employee.setSupervisor(secretary);
        }else if(name.equals(boss.getName())){
            employee.setSupervisor(boss);
        }else if(name.equals(salesman.getName())){
            employee.setSupervisor(salesman);
        }else{
            System.out.println("Nombre incorrecto");
        }
    }
    
    public static void agregarCliente(Scanner input,Empleado employee){
        System.out.println("Nombre cliente");
        String name = input.next();
        System.out.println("ID del cliente");
        String id = input.next();
        System.out.println("Edad del cliente");
        String age = input.next();
        
        if(employee.equals(salesman)){
            clientSalesman = new Cliente(name,id,age);
        }else{
            clientBoss = new Cliente(name,id,age);
        }
    }
    
    public static void eliminarCliente(Scanner input,Empleado employee){
        String name="";
        if(employee.equals(salesman)){
            name=clientSalesman.getName();
        }else{
            name=clientBoss.getName();
        }
        System.out.println("Seguro que desea eliminar al vendedor "+name+"? (Si=1,No=0)");
        int select=0;
        do{
            select = input.nextInt();
            if(select!=0&&select!=1){
                System.out.println("Seleccion no valida");
            }
        }while(select!=0&&select!=1);
        if(select==1&&employee.equals(salesman)){
            clientSalesman.setName(" ");
            clientSalesman.setID(" ");
            clientSalesman.setAge(" ");
        }else{
            clientBoss.setName(" ");
            clientBoss.setID(" ");
            clientBoss.setAge(" ");
        }
    }
}
