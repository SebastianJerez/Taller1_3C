/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Empresa;

/**
 *
 * @author LabSispc20
 */
public class Empleado {
    private String name;
    private String surname;
    private String dni;
    private String address;
    private double salary;
    private int yearsOfService;
    private String phoneNumber;
    private Empleado supervisor;

    public Empleado(String name, String surname, String dni, String address, double salary, String phoneNumber, int yearsOfService) {
        this.name = name;
        this.surname = surname;
        this.dni = dni;
        this.address = address;
        this.salary = salary;
        this.phoneNumber = phoneNumber;
        this.yearsOfService = yearsOfService;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getDni() {
        return dni;
    }

    public String getAddress() {
        return address;
    }

    public double getSalary() {
        return salary;
    }

    public int getYearsOfService() {
        return yearsOfService;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public Empleado getSupervisor() {
        return supervisor;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setYearsOfService(int yearsOfService) {
        this.yearsOfService = yearsOfService;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setSupervisor(Empleado supervisor){
        this.supervisor = supervisor;
    }
  
    @Override
    public String toString() {
        return "Empleado{" + "name=" + name + ", surname=" + surname + ", dni=" + dni + ", address=" + address + ", salary=" + salary + ", yearsOfService=" + yearsOfService + ", phoneNumber=" + phoneNumber + ", supervisor=" + supervisor.getName() + '}';
    }
    
    public void increastSalary(){
    }
    

        
    
}
