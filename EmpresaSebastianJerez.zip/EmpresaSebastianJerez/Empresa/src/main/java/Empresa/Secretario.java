/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Empresa;

/**
 *
 * @author LabSispc20
 */
public class Secretario extends Empleado {
    private String office;
    private String faxNumber;

    public Secretario(String office, String faxNumber, String name, String surname, String dni, String address, double salary, String phoneNumber, int years) {
        super(name, surname, dni, address, salary, phoneNumber, years);
        this.office = office;
        this.faxNumber = faxNumber;
        for(int i=0;i<years;i++){
            this.increastSalary();
        }
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    @Override
    public String toString() {
        return "Secretario{" + "name=" + this.getName() + ", surname=" + this.getSurname() + ", dni=" + this.getDni() + ", address=" + this.getAddress() + ", salary=" + this.getSalary() + ", yearsOfService=" + this.getYearsOfService() + ", phoneNumber=" + this.getPhoneNumber() + "office=" + office + ", faxNumber=" + faxNumber + '}';
    }
    
    @Override
    public void increastSalary(){
        double salary = this.getSalary();
        salary = salary+(salary*0.05);
        this.setSalary(salary);
    }
    
    
}
