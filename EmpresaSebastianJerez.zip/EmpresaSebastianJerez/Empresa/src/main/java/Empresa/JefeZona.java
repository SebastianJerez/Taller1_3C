/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Empresa;

import java.util.ArrayList;

/**
 *
 * @author LabSispc20
 */
public class JefeZona extends Empleado{
    private String office;
    private Secretario secretary;
    private Cliente client;
    private Coche vehicle;

    public JefeZona(String office, String name, String surname, String dni, String address, double salary, String phoneNumber, int yearsOfService) {
        super(name, surname, dni, address, salary, phoneNumber, yearsOfService);
        this.office = office;
        for(int i=0;i<this.getYearsOfService();i++){
            this.increastSalary();
        }
    }

    @Override
    public String toString() {
        return "JefeZona{" + "name=" + this.getName() + ", surname=" + this.getSurname() + ", dni=" + this.getDni() + ", address=" + this.getAddress() + ", salary=" + this.getSalary() + ", yearsOfService=" + this.getYearsOfService() + ", phoneNumber=" + this.getPhoneNumber() + "office=" + office + ", secretary=" + secretary.getName() + '}';
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }
    
    public void setVehicle(Coche vehicle) {
        this.vehicle = vehicle;
    }

    public Secretario getSecretary() {
        return secretary;
    }

    public void setSecretary(Secretario secretary) {
        this.secretary = secretary;
    }

    public Cliente getClient() {
        return client;
    }

    public void setClient(Cliente client) {
        this.client = client;
    }
    
    @Override
    public void increastSalary(){
        double salary = this.getSalary();
        salary = salary+(salary*0.2);
        this.setSalary(salary);
    }
    
}
